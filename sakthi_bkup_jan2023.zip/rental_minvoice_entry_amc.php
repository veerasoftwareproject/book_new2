<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | General Form Elements</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
  
<?php
include 'nav.php';
?>  

<div class="content-wrapper">

<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Invoice/AMC</a></li>
              <li class="breadcrumb-item active">New Entry</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


   <div class="card card-success">
        <div class="card-header">
           <h3 class="card-title"> MACHINE & SPARE-INVOICE ENTRY  / AMC</h3>
        </div>

          <div class="alert alert-light" role="alert" style="background">
        <div class="container overflow-hidden">
          <div class="card-body card-light">
           <div class="form-group row">
               <div class="col-sm-6">
                <label class="col-sm-2 col-form-label">Date :</label>
                <input type="date" class="form-control" value="<?php echo date('Y-m-d'); ?>" id="date">
              </div>

              <div class="col-sm-6">
                <label class="col-sm-6 col-form-label">Reference :</label>
                <input type="text" class="form-control" id="ref">
              </div>
            </div>

            <div class="form-group row">
              <div class="col-sm-6">
                <label class="col-sm-8 col-form-label">AMC No :</label>
                <input type="text" class="form-control" id="bill">
              </div>

            <div class="col-sm-6">
                <label class="col-sm-6 col-form-label">Customer :</label>
  <select class="form-control custom-select-value" name="account" id="custom">
        <option>- Select one -</option>
<?php
include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$qr1=mysqli_query($link,"select distinct(company) from tblcustomer where company!=''");
while($dt1=mysqli_fetch_array($qr1))
{        
  ?>
        <option value="<?php echo$dt1['company']; ?>"><?php echo$dt1['company']; } ?></option>

</select>

              </div>
            </div>

            <div class="row">
              
               <div class="col-sm-4">
                <label for="ptype" class="col-sm-12 col-form-label">Details</label>
                    <div class="col-sm-12">
                    <select class="form-control custom-select-value" name="account" id="detail">
                    <option>- Select one -</option>
<?php
$qr11=mysqli_query($link,"select distinct(pname) from tblstock where pname!=''");
while($dt11=mysqli_fetch_array($qr11))
{        
  ?>
        <option value="<?php echo$dt11['pname']; ?>"><?php echo$dt11['pname']; } ?></option>             
</select>
      </div>
              </div>

             
                <div class="col-sm-4">
                <label class="col-sm-12 col-form-label">Quantity :</label>
                <input type="text" name="" class="form-control"  id="quant"> 
              </div>

              <div class="col-sm-4">
                <label class="col-sm-12 col-form-label">Rate :</label>
                <input type="text" name="" class="form-control"  id="rate"> 
              </div>
 

              <!-- <div class="col-sm-4">
                <label class="col-sm-6 col-form-label">D.O.Reading :</label>
                <textarea class="form-control" rows="3" id="doread"></textarea>
              </div> -->
            </div>
          </div>
            <input type="button" value="ADD" id="btnsave" class="btn btn-primary float-right">
          </div>

          <div class="card-body">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <!-- <th style="width: 10px;">S.N0</th> -->
                      <th>Details</th>
                   
                      <th>Quantity</th>
					   <th>Rate</th>						
                      <th style="width: 10px;">Delete</th>
                    </tr>
                  </thead>
                  <tbody id="empty">
                  </tbody>
                </table>
              </div><br>

               <div class="form-group row">
               <div class="col-sm-6">
                <label class="col-sm-6 col-form-label">CGST %:</label>
                <input type="number" class="form-control" id="cgst">
              </div>

              <div class="col-sm-6">
                <label class="col-sm-6 col-form-label">SGST %:</label>
                <input type="number" class="form-control" id="sgst">
              </div>

               <!-- <div class="col-sm-2">
                <label class="col-sm-12 col-form-label">Search :</label>
                <input type="text" class="form-control" id="search">
              </div> -->

              <!-- <div class="col-sm-3"> -->
                <!-- <label class="col-sm-12 col-form-label">Service Charge :</label> -->
                <!-- <input type="number" class="form-control" id="scharge"> -->
              <!-- </div> -->
              <!-- <div class="col-sm-3">
                <label class="col-sm-12 col-form-label">Freight Charges :</label>
                <input type="number" class="form-control" id="pack">
              </div> -->
            </div>

              <input type="button" value="CONFIRM" id="btnconfirm" class="btn btn-primary float-right">
          </div>
      </div>
     </div>
    </div>
    


  <!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnsave").click(function(){
      var det = $("#detail").val();
      var rate = $("#rate").val();
      var qty = $("#quant").val();

      var x ="<tr><td class='b1'>"+det+"</td><td class='b3'>"+qty+"</td><td class='b2'>"+rate+"</td><td><i class='fa-solid fa-trash-can' id='y'></i></td><tr>";

      $("tbody").append(x);

       $("#detail").val("");
       $("#rate").val("");
       $("#quant").val("");
       $("#detail").focus();
       


    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnconfirm").click(function(){
      // alert("helo");
      var mrdate= $("#date").val();
      var ref = $("#ref").val();
      var bno = $("#bill").val();
      var customer = $("#custom").val();
      var cgst = $("#cgst").val();
      var sgst = $("#sgst").val();
      // var search = $("#search").val();
      // var scharge = $("#scharge").val();
      // var pack = $("#pack").val();
      // alert(pack);

      $.ajax({
        url:"rental_minvoice_sdata_amc.php",
        method:"GET",
        data:{mrdate:mrdate, ref:ref, bno:bno, customer:customer, cgst:cgst, sgst:sgst},
        success:function(response){
          alert("rental m invoice s data collected");
        }

      });



    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnconfirm").click(function(){

      var bno = $("#bill").val();
      var ar1 = [];
      var ar2 = []; 
      var ar3 = [];

      $(".b1").each(function(){
        ar1.push($(this).text());
      });
      // alert(ar1);

      $(".b2").each(function(){
        ar2.push($(this).text());
      });

      $(".b3").each(function(){
        ar3.push($(this).text());
      });
      // alert(ar3);

      $.ajax({
        url:"rental_minvoice_adata_amc.php",
        method:"GET",
        data:{bno:bno, ar1:ar1, ar2:ar2, ar3:ar3},
        success:function(response){
          alert("rental m invoice a data collected");
        }
      });

      window.location.href="rental_minvoice_entry_amc.php";


    });
  });
</script>