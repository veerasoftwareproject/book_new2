<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$tempname="" ;
$folder="";


$date=$_POST["pur_date"];
$ref=$_POST["pur_ref"];
$bno=$_POST["pur_bill"];
$customer=$_POST["pur_custom"];
$cgst=$_POST["pur_cgst"];
$sgst=$_POST["pur_sgst"];
// $search=$_GET["search"];
$scharge=$_POST["pur_other"];
// $pack=$_GET["pack"];



// *****************************IMAGE ******************************************************************************
$statusMsg2 = ''; 
if(!empty($_FILES["pur_image"]["name"])) { 

    $filename = $_FILES["pur_image"]["name"];
    $tempname = $_FILES["pur_image"]["tmp_name"];
    $folder = "./pur_image/" . $filename;
}else{ 
    $filename="";
    $statusMsg2 = 'Please select an image file 2 to upload.'; 
} 




$sql="insert into tblnew_purchase(pdate,preference,pbillno,psupplier,pcgst,psgst,pothercharge,pupload)values('$date','$ref','$bno','$customer','$cgst','$sgst','$scharge','$filename')";

echo$sql;

mysqli_query($link, $sql);
if(move_uploaded_file($tempname,$folder)){
    header("location:purchase_entry_new.php?contact_name='hi'");
    echo "<script>alert('Records added successfully'); </script>";
    } else{
    $tempname="" ;
    $folder="";
    header("location:purchase_entry_new.php?contact_name='hi'");
}
    




// $result=mysqli_query($link,$sql);

// echo$sql;
?>