<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>receipt page</title>
    <link rel="stylesheet" href="receipt.css">
</head>
<body>
<?php 
$new_id = $_GET['id'];
$rs = $_GET['rs'];

include"no2text.php";

include "dbconnect.php";

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblpayment where id='$new_id'");
$ct=0;
// echo"helo batman::):  select * from tblpayment where pay_billno='$new_id'";
while($dt=mysqli_fetch_array($qr)){
$amt = $dt['pay_amt'];
 
// $tot_amt=1000;
$get_amount= AmountInWords($rs);
$s_type=$dt['pay_type'];
$s_bno  = $dt['pay_billno'];
if($s_type=="Sales"){
	$qr1=mysqli_query($link,"select * from tblnew_invoice_sales where inv_sal_bno='$s_bno'");
	while($dt1=mysqli_fetch_array($qr1)){
		$s_name = $dt1['inv_sal_cname']; 
	}
}else if($s_type=='AMC'){
	$qr2=mysqli_query($link,"select * from tblamc where amc_no='$s_bno'");
	while($dt2=mysqli_fetch_array($qr2)){
		$s_name = $dt2['amc_name']; 
	}
}else if($s_type=='Rental'){
	$qr3=mysqli_query($link,"select * from tblnew_invoice_rental where inv_ren_bno ='$s_bno'");
	while($dt3=mysqli_fetch_array($qr3)){
		$s_name = $dt3['inv_ren_cname']; 
	}	
}
	// echo"\t\t BillNO:\t\t\t ".$dt['pay_billno'];  
?>
	<div class="main">
    <h3>RECEIPT</h3>
    <h2>SAKTHI COPIER</h2>
    <h4>H.O. : 17/S, Perumal South Car Street, Tirunelveli - 627 001</h4>
    <h4>B.O. :  36A,Subbiahpuram,2nd Street,Tuticorin-3.</h4>
    <h4>cell: 94431-72023, 99940-28206</h4>
    <div class="no"> No.<?php echo$s_bno; ?></div><div class="date">Date :<?php echo$dt['pay_date']; ?></div><br>

    <p>Received with thanks form M/s. <span style="  border-bottom: 1px black dotted; margin:100px;"><?php echo$s_name;?> </p>
        <!-- <p>..................................................................................................................................................................................................................................................................</p> -->
        <p>the sum of Rupees <span style="margin:80px;"> <?php echo$get_amount."Only"; ?></span></p>
        <p>..................................................................................................................................................................................................................................................................</p>
        <p>towards <span style="margin:150px;"> <?php echo$dt['pay_mode']; ?></span></p>
        <p>by Cash / Draft / Cheque ...................................................</p>
        <p>No .............................................. Dated ..............................................</p>
        <small>(Cheque & Drafts subject to Reallsation)</small>
        <div class="box">For SAKTHI COPIER</div><br><br>
        <div class="box1">Rs.	&nbsp;	&nbsp;	&nbsp; <?php echo$rs; } ?></div>
        <div class="box2">THANKS</div>
        <div class="box3"></div> 
    </div>
</body>
</html>