<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();
$c_type = $_GET['c_type'];
$fname = $_GET["fname"];
//$lname = $_GET["lname"];
$gender = $_GET["gender"];
$company = $_GET["company"];
$caddress = $_GET["caddress"];
$phone = $_GET["phone"];
$email = $_GET["email"];
$uname = $_GET["uname"];
$pwd = $_GET["pwd"];
$status = $_GET["status"];
$group = $_GET["group"];
// echo"working".$group;

$sql="insert into tblcustomer(cus_type,fname,gender,company,phone,email,uname,pwd,cstatus,cgroup,caddress)values('$c_type','$fname','$gender','$company','$phone','$email','$uname','$pwd','$status','$group','$caddress')";


$result=mysqli_query($link,$sql);

 echo$sql;



?>