<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | General Form Elements</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <style type="text/css">
  	*{
  		font-size: 1em;
  		color: black;
  	}
  	#bold{
  		font-weight: bold;
  	}
  	#center{
  		text-align: center;
  	}
  	.special{
  		/*font-size: 18px;*/
  	}
  	table{
  		width: 90%;
  		margin: 10px;
  	}
  	th, tr, td{
  		border: 1px solid black;
  		border-color: black;
  		padding: 14px;
  	}
  </style>
</head>
<body><br>
<center> <b> "V FOR U" </b></center>
	<center><b>INVOICE </b><span style="float:right;"><b> Original </b></span>
	<table class="">
	<?php

include 'dbconnect.php';

$id=$_GET['id'];

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblnew_invoice_rental where inv_ren_bno='$id'");


while($dt=mysqli_fetch_array($qr)){



?>

		<!-- <caption>Invoice</caption> -->
		<tr>
			<td  colspan ="2" rowspan="3" id="bold">Sakthi Copier<br>36,A subbaiahpuram<br>2nd street,<br>Thoothukudi.<br><b>Ph:0461 2337755/94431 72023</b></td>
			
			<td ></td>
			<td id="bold"><center>Dated :<br><?php echo$dt['inv_ren_date'];  ?></center></td>
		</tr>




		<tr>
			<td colspan="" id="bold"><center>Bill No  /  HSN Code</center></td>
			<td colspan="" id="bold"><center>Customer Code</center></td>
		</tr>



		<tr>
			<td colspan=""><center><?php echo$dt['inv_ren_bno']; ?>/ 9973</center></td>
			<td colspan=""><center><?php echo$dt['inv_ren_code'];  ?></center></td>
		</tr>


		<tr>
			<td colspan="2" rowspan="2" id="bold">M/S.<?php echo$dt['inv_ren_cname']; ?>,<br>
			<?php 
	$n1= $dt['inv_ren_cname'];
	$cqr=mysqli_query($link,"select * from tblcustomer WHERE company='$n1'");
	while($cdt=mysqli_fetch_array($cqr)){
	echo$cdt['caddress']; ?>,<br>
<?php echo$cdt['phone']; } ?>
			</td>
			<td colspan="" id="bold"><center>M/c Model No</center></td>
			<td colspan="" id="bold"><center>M/c Serial No</center></td>
		</tr>
		

		<tr>
			<td colspan=""><center><?php echo$dt['inv_ren_mno']; ?></center></td>
			<td colspan=""><center><?php echo$dt['inv_ren_slno'];  ?></center></td>
		</tr>

		<tr>
			<th colspan="" id="center"><b>DESCRIPTION</b></th>
			<th colspan="" id="center"><b>METER READING</b></th>
			<th colspan="" id="center"><b>DATE OF READING</b></th>
			<th id="center"><b>AMOUNT</b></th>
		</tr>



		<tr>
			<td colspan="">Monthly Rent Amount</td>	
			<td colspan=""></td>
			<td colspan=""></td>
			<td id="bold">Rs:<?php $monthly_amt = $dt['inv_ren_month_rent']; echo$dt['inv_ren_month_rent']; ?></td> 
		</tr>
		

		<tr>
			<td colspan="">Current Month meter reading</td>
			<td colspan="" id="center"><?php echo$dt['inv_ren_mread'];  ?></td>
			<td colspan="" id="center"><?php echo$dt['inv_ren_mdate']; ?></td>
			<td colspan=""></td> 
		</tr>
		<tr>
			<td colspan="">Starter meter reading</td>	
			<td colspan="" id="center"><?php echo$dt['inv_ren_pread']; ?></td>
			<td colspan="" id="center"><?php echo$dt['inv_ren_pdate']; ?></td>
			<td></td> 
		</tr>
		<tr>
			<td colspan="">Gross reading</td>	
			<td colspan="" id="center"><?php 
			
			$gross_read = $dt['inv_ren_mread'] - $dt['inv_ren_pread']; echo$gross_read;  $ans = $gross_read - $dt['inv_ren_sno1']; ?></td>
			<td colspan=""></td>
			<td></td> 
		</tr>
		<tr>
			<td colspan="">Net Billable Copies</td>	
			<td colspan="" id="center"><?php  if($ans>0){  $tot_amt = $ans * $dt['inv_ren_pcc'] ; } else { $ans=0; $tot_amt=0; } echo$ans; ?>*<?php echo$dt['inv_ren_pcc']; ?></td>
			<td colspan=""></td>
			<td>Rs:<?php  echo$tot_amt;  ?></td> 
		</tr>
		<tr>
			<td colspan="">Charges @ Rs.<?php echo$dt['inv_ren_pcc']; ?> Per Copy </td>	
			<td colspan=""></td>
			<td colspan="">Round off</td>
			<td>Rs:000.00</td> 
		</tr>
		<tr>
			<td colspan="2"></td>
			<td>Total Amount</td>	
			<td id="bold">Rs:<?php  $tot_amt2 = $monthly_amt + $tot_amt;  echo$tot_amt2;  ?></td> 
		</tr>
		<?php 
include"no2text.php";
$get_amount= AmountInWords($tot_amt2);
?>


		<tr>
			<td colspan="4">AMOUNT IN WORDS : Rupees <?php echo$get_amount; ?> only </td>
		</tr>
		<tr>
			<td colspan="4"><b>*NOTE :OFFICE WORKING HOURS 10.00 AM TO 6.00 PM</b></td>
		</tr>
		<tr>
			<td style="padding-bottom: 2em; padding-top: 2em; text-align: center;">(Customer's<br> signature with Name<br> and Stamp)</td>
			<td colspan="2"><span style="text-decoration: underline;" id="bold">RTC OR NEFT PAYMENT DETAILS:</span><br>ACCOUNT HOLDER NAME:<b> SANKARANARAYANAN SORIMUTHU</b><br>BANK:<b>TAMILNADU MERCANTILE BANK</b><br>ACCOUNT NUMBER:<b>174100050325871</b><br>IFSC:<b>TMBL0000174</b><br>BRANCH:<b> KAMARAJ COLLEGE BRANCH</b><br>AREA:<b>THOOTHUKUDI</b></td>	
			<td colspan="" id="bold"><center><span style="">CSMA<br><br>Per copy <?php echo$dt['inv_ren_pcc']; } ?> paise</span></center></td>
		</tr>
		<tr>
			<td colspan="3" id="bold"><center>PAYABLE TO <span class="special"> SAKTHI COPIER</span></center></td>
			<td colspan="" rowspan="2"><b>FOR SAKTHI COPIER</b><br><br><br><br><br>AUTHORISED SIGNATURE</td>
		</tr>
		<tr>
			<td colspan="3" id="center">PLEASE PAY BY CROSSED CHEQUE / DEMAND DRAFT ONLY</td>	
		</tr>						
		
	</table>
</body>
</html>