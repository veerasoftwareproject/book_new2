<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SAKTHI COPIER | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<?php
include 'nav.php';
?>


<?php
// include "crud.php";

// $obj = new crud();

// $id=1;//$_GET['id'];

// $data=$obj->displayid("tblbiller","bfname",$id);
// $ct=0;
// foreach ($data as $get) {
// $ct=$ct+1;



?> 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Invoice Sales Payment Page</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <!-- /.card -->
            <!-- Horizontal Form -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">SALES PAYMENT ENTRY</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->

<?php 
$billno = $_GET['id'];
include "dbconnect.php";

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblnew_invoice_sales where inv_sal_bno='$billno'");
$ct=0;

while($dt=mysqli_fetch_array($qr)){


?>

              <form class="form-horizontal">
                <div class="card-body">
                  <div class="form-group row">
                    <label for="pname" class="col-sm-2 col-form-label">Bill Number</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" value="<?php echo $dt['inv_sal_bno'];?>" id="bill_no" readonly>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Bill Date</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" disabled value="<?php echo$dt['inv_sal_date'];?>" id="lname" placeholder="">
                    </div>  
                  </div>


                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Customer Name</label>
                    <div class="col-sm-10">
                      <input type="text" value="<?php echo$dt['inv_sal_cname'];  ?>" id="customer_name" class="form-control" disabled>
                      <!-- </select> -->
                      </div>
                  </div>

<?php 
$qr2=mysqli_query($link,"select sum(inv_sal_qty * inv_sal_rate)as btotal from tblnew_invoice_sales_details where inv_sal_bno='$billno'");
$bill_taxable_total=0;
while($dt2=mysqli_fetch_array($qr2)){
$bill_taxable_total = $dt2['btotal'];
}

$cgst_amt = $dt['inv_sal_cgst']* $bill_taxable_total * 0.01;
$sgst_amt = $dt['inv_sal_sgst']* $bill_taxable_total * 0.01;
$bill_amount = $bill_taxable_total + $sgst_amt +$cgst_amt+$dt['inv_sal_scharge']+$dt['inv_sal_fcharge'];


								   if($dt['inv_sal_paid_amt']==""){
									   $paid_amt=0;
								   }
								   else{
									   $paid_amt = $dt['inv_sal_paid_amt'];
								   }
								   $ans = $bill_amount - $paid_amt;			

} 

?>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Bill Amount </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" value="<?php echo "Rs.".$ans;?>" id="bill_amount" placeholder="" disabled>
                    </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Payment Amount </label>
                    <div class="col-sm-10 input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-currency">Rs.</i></span>
						<input type="hidden" id="pay_amt_old" value='<?php echo$paid_amt; ?>'>
                      <input type="text" class="form-control" value="" id="payment_amount" placeholder="">
                    </div>
                  </div>

                  <div class="form-group row">
                     <label for="pcode" class="col-sm-2 col-form-label">Payment Date</label>
                      <div class="col-sm-10 input-group-prepend">
                        <!-- <span class="input-group-text">@</span> -->
                        <input type="date" class="form-control"  id="payment_date" placeholder="">
                      </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Payment Type </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control"  id="payment_type" placeholder="">
                    </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label"> Remarks </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="remarks" placeholder="">
                    </div>
                  </div>

                


                  
                  <!-- </div> -->
                 
                <!-- /.card-body -->
                <!-- <div class="card-footer"> -->
                 
                  <input type="button" id="btnconfirm" value="CONFIRM" class="btn btn-info float-right">
                <!-- </div> -->
                <!-- /.card-footer -->
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 </body>
 </html>
 <script type="text/javascript">
   $(document).ready(function(){
      $("#btnconfirm").click(function(){
        // alert("hello");

        var bill_no = $("#bill_no").val();
        var pay_date = $("#payment_date").val();
        var pay_type = $("#payment_type").val();
        var pay_amount_new = $("#payment_amount").val();
		var pay_amt_old = $("#pay_amt_old").val();
		var pay_amount =parseInt(pay_amount_new)+parseInt(pay_amt_old);
		 var pay_emi = $("#payment_amount").val();
        var remarks= $("#remarks").val();
        // var customer_name = $("#customer_name").val();

		alert(bill_no+pay_date+pay_type+pay_amount);

        // var buname = $("#uname").val();
        // var bpwd = $("#pwd").val();
        // var bstatus = $("#status").val();
        // var bgroup = $("#group").val();
         // alert(bgender);

        // alert(bgroup);


        $.ajax({

          url : "invoice_payment_entry_data.php",
          method : "GET",
          data : {bill_no:bill_no, pay_date:pay_date, pay_type:pay_type, pay_amount:pay_amount, remarks:remarks,pay_emi:pay_emi},
          success : function(response){
            alert("Payment Entry Saved");
          }

        });
        window.location.href="sales_invoice_display.php";

      });

    });

 </script>