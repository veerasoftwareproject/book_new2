<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];

$sql="Delete from tblexpense where id='$rid'";
$res=mysqli_query($link,$sql) or die(mysqli_error());
echo$sql;
header("location:expense_list.php");


?>