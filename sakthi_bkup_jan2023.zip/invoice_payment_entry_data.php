<?php

include 'dbconnect.php';
$object = new db_conn();
$link=$object-> connection();


$pay_amt = $_GET["pay_amount"];
 $pay_date = $_GET["pay_date"];
 $pay_mode = $_GET["pay_type"];
 $pay_remarks= $_GET["remarks"];
 $pay_billno = $_GET['bill_no'];
$pay_emi = $_GET['pay_emi'];


 $sql="insert into tblpayment(pay_billno,pay_amt,pay_date,pay_mode,pay_remarks,pay_type,pay_emi)values('$pay_billno','$pay_amt','$pay_date','$pay_mode','$pay_remarks','Sales','$pay_emi')";

 if(mysqli_query($link, $sql)){
    // header("location:sales_payment.php?contact_name='hi'");
    // echo "<script>alert('Records added successfully'); </script>";
    echo$sql;
    } else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }


$sql2 = "update tblnew_invoice_sales set inv_sal_paid_amt='$pay_amt' where inv_sal_bno='$pay_billno'";
mysqli_query($link,$sql2);

 echo$sql;
?>