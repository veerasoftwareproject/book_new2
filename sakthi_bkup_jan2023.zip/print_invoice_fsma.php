<!DOCTYPE html>
<html>
<head>
<style>
	body{
		font-family: "Times new roman"
	
	}
	div{
		overflow-x: auto;
	}
	table{
		border-collapse: collapse;
		border-spacing: 0;
		width: 100%;
		height:100%;
		border: 1px solid rgb(0,0,0);
	}
	th,td{
		text-align: left;
		padding: 6px;
		border: 1px solid black;
	}
	label{
		font-size: 1.5em;

	}
	p{
		font-size: 25px;
	}
	

</style>
</head>
<body>
	
	<br><br>
<center> <b> "V FOR U" </b></center>
	<center><b>INVOICE </b><span style="float:right;"><b> Original </b></span> 

	<table>

	<?php

include 'dbconnect.php';

$id=$_GET['id'];

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblnew_invoice_rental where inv_ren_bno='$id'");


while($dt=mysqli_fetch_array($qr)){



?>
	


		<tr>
			<td rowspan="3"><label>Sakthi Copier</label><br>
			32 A,Subbaihpuram,2nd street,<br>
			Thoothukudi.<br>
			<b><i>Ph:94431 72023 / 90033 54099</i></b></td>
			<td colspan="2"><b>GSTIN : 33BOBPS2206C1ZL<br>
				PAN NO : BOBPS2206C<br>
			C.S.T.NO : 525925</td></b>
			<td colspan="2"><b> Dated :<br>
			<?php echo$dt['inv_ren_date'];  ?></td></b>
		</tr>
		<tr>
			<td><b>Invoice / Bill No</b></td>
			<td><b>HSN / SAC</b></td>
			<td><b>Customer Code</b></td>
		</tr>
		<tr>
			<td><?php echo$dt['inv_ren_bno'];  ?></td>
			<td>9973</td>
			<td><?php echo$dt['inv_ren_code'];  ?></td>
			
		</tr>
		<tr>
			<td rowspan="2"><?php echo$dt['inv_ren_cname'];  ?>
				<br> <?php 
	$n1= $dt['inv_ren_cname'];
	$cqr=mysqli_query($link,"select * from tblcustomer WHERE company='$n1'");
	while($cdt=mysqli_fetch_array($cqr)){
	echo$cdt['caddress']; ?>,<br>
<?php echo$cdt['phone']; } ?>
				
			<!--	P&A, RCS / TTPS,<br>
				Thoothukudi.3.<br>
			<b>GSTIN: 33AADCT4784E1ZC</b> --></td><br>
			<td colspan="2"><b>M/c Model No.</b></td>
			<td colspan="2"><b>M/c Serial No.</b></td>
		</tr>
		<tr>
			<td colspan="2"><?php echo$dt['inv_ren_mno'];  ?></td>
			<td><?php echo$dt['inv_ren_slno'];  ?></td>
		</tr>
		<tr>
			<th>DESCRIPTION</th>
			<th>METER READING</th>
			<th>DATE OF READING</th>
			<th>AMOUNT</th>
		</tr>
		<tr>
			<td>MONTHLY RENTAL</td>
			<td></td>
			<td></td>
			<td><b>RS.<?php $month_rate=$dt['inv_ren_month_rent']; echo$dt['inv_ren_month_rent'];  ?></b></td>
		</tr>
		<tr>
			<td>Current month meter reading</td>
			<td><?php echo$dt['inv_ren_mread'];  ?></td>
			<td><?php echo$dt['inv_ren_mdate'];  ?></td>
			<td></td>
		</tr>
		<tr>
			<td>Last meter reading</td>
			<td><?php echo$dt['inv_ren_pread'];  ?></td>
			<td><?php echo$dt['inv_ren_pdate'];  ?></td>
			<td></td>
		</tr>
		<tr>
			<td>Gross Readings</td>
			<td>
			<?php 
			$gross_read = $dt['inv_ren_mread'] - $dt['inv_ren_pread']; echo$gross_read; ?>
			</td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td>Net Billable Copies</td>
			<?php  $ans = $gross_read - $dt['inv_ren_sno1'];  if($ans >0){ $tot_amt = $ans* $dt['inv_ren_pcc']; } else { $ans=0; $tot_amt=0; }  $full_amount = $tot_amt + $month_rate;	   ?>
			<td><?php echo$ans; ?>*<?php echo$dt['inv_ren_pcc'];?></td>
			<td></td>
			<td><b>Rs.<?php echo$tot_amt; ?></b></td>
		</tr>
		<tr>
			<td>Out put-State tax</td>
			<td>SGST-</td>
			<td><?php echo$dt['inv_ren_sgst'];  if($tot_amt==0){ $tot_amt=0; }  $gst_amt = $dt['inv_ren_sgst']*0.01*$full_amount; ?>%</td>
			<td><b>Rs. <?php echo$gst_amt; ?></b></td>
		</tr>
		<tr>
			<td>Out put-Central tax</td>
			<td>CGST-</td>
			<td><?php echo$dt['inv_ren_sgst'];  $gst_amt2 = $dt['inv_ren_cgst']*0.01 * $full_amount ; $net_amt = $gst_amt + $gst_amt2 + $tot_amt;  ?>%</td>
			<td><b>Rs. <?php echo$gst_amt2; ?></b></td>
		</tr>
		<tr>
			<td>Charges @ Rs. <?php echo$dt['inv_ren_pcc'];  ?> Per Copy</td>
			<td></td>
			<td>Rounded off add</td>
			<td><b>Rs. 0000</b></td>
		</tr>
		<tr>
			<td colspan="3">Total Amount</td>
			<td><b>Rs. <?php $final_ans = $dt['inv_ren_month_rent'] +$tot_amt+$gst_amt+$gst_amt2;  echo$final_ans; } ?></b></td>
		</tr>
		<?php 
include"no2text.php";
$get_amount= AmountInWords($net_amt);
?>
		<tr>
			<td colspan="4">
				AMOUNT IN WORDS: Rupees <?php echo$get_amount; ?> Only
			</td>
		</tr>
		<tr>
			<td colspan="4"><b>*NOTE: OFFICE HOURS 10.00AM TO 6.00PM</b></td>
		</tr>
		<tr>
			<td colspan="1"><br>
				<br>
				<br>
				<br>
				<br>(Customer's Signature With Name and Stamp)</td>
			<td colspan="3"><b>Company Bank Details</b><br>
				Name: State Bank of India<br>
			Account Number: 31699658816<br>
			Branch IFSC Code: SBIN0014463<br>
			Branch: Thoothukudi.</td>
		</tr>
		<tr>
			<td colspan="2">PAYABLE TO <b><p>SAKTHI COPIER</b></p></td>
			<td rowspan="2" colspan="2"><b>FOR SAKTHI COPIER</b><br>
				<br>
				<br>
				<br>
				<br>
				<br>	
				<br>
				<br>
				AUTHORISED SIGNATURE
			</td>
		</tr>
		<tr>
			<td colspan="2">PLEASE PAY BY CROSSED CHEQUE / DEMAND DRAFT ONLY</td>
		</tr>
		</table>
</body>
</html>