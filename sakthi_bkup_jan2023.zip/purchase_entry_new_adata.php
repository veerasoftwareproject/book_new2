<?php
include 'dbconnect.php';
$object = new db_conn();
$link=$object-> connection();
$bno= $_GET["bil"];
$a = $_GET["ar1"];
$b = $_GET["ar2"];
$c = $_GET["ar3"];
// echo$vt2;
for ($i=0; $i<count($a); $i++)
{
      $query="insert into tblnew_purchase_details(pbillno,pdetails,pqty,prate)
	  values('$bno','$a[$i]','$b[$i]','$c[$i]')";
      echo$query;
    if(mysqli_query($link, $query)){
      // header("location:stock_entry.php?contact_name='hi'");
      // echo "<script>alert('Records added successfully'); </script>";
      echo$query;
      }
    //   $qrexe = $conn->query($query);

}
?>








<!-- ?> -->