<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<style type="text/css">
	table{
		width: 100%;
		border-collapse: collapse;
		line-height: 25px;
		/*border: 1px solid black;*/
	}
	#customer_col{
		width: 80%;
	}
	#ps{
		width:2% !important;
	}
	#qty{
		width: 5% !important;
	}
	#slno{
		width: 5% !important;
		text-align: center;
	}
	#rate{
		width: 15% !important;
		text-align: right;
	}
	#one{
		width: 60% !important;
	}
	#two{
		width: 25% !important;
	}
	#three{
		width: 15% !important;
	}
</style>
<body>
	<br><br>
<table border="1">
	<tr>
		<td><span>SAKTHI COPIER</span><br>17/5Perumal Car Street, Tirunelveli-627001.<br>36A,Subbiahpuram,2nd Street,Tuticorin-3.<br>Cell:94431-72023/99940 28206.</td>
		<td>Our Sales Tax Number<br>GST IN :33BOBPS2206C1L<br>Pan No;BOBPS2206C</td>
	</tr>
</table>
<table border="1">
		<tr style="border-top: none;">
			<td id="customer_col" rowspan="4"><span>Customer</span><br>MS.Blackstone Shipping Private Limited.<br>48/209A,C.G.E Colony 5th Street,<br>Thoothukudi.<br><b>GST NO:33AAICB8190P1Z2</td>
			<td colspan="">AMC Inv.No.</td>
			<td colspan="">1234</td>
			<!-- <td></td>	 -->
		</tr>
		<tr>
			<td colspan="">Date</td>
			<td colspan="">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="">Your Ref.No.</td>
			<td colspan="">KY-577</td>
		</tr>
		<tr>
			<td colspan="">Date</td>
			<td colspan="">05.02.2022</td>
		</tr>
</table>
<table border="1">
		<tr style="border-top:none;">
			<th rowspan="" style="width:2% !important;" id="slno">SI.No.</th>	
			<th colspan="2" rowspan="">Description</th>
			<th rowspan="" id="qty">Qty.</th>
			<th colspan="3"  id="rate" rowspan="">Unit Price</th>
			<th colspan="2" rowspan="">Amount</th>
		</tr>
		<tr>
			<td  id="slno" style="border-top: hidden;"></td>
			<td colspan="2" style="border-top: hidden;"></td>
			<td style="border-top: hidden;" id="qty"></td>
			<td colspan="2">RS.</td>
			<td id="ps">Ps.</td>
			<td>RS.</td>
			<td id="ps">Ps.</td>
		</tr>
		<tr>
			<td>1</td>
			<td colspan="2">Kyocera 2040</td>
			<td>1 no</td>
			<td colspan="2" style="text-align:right;">32,794</td>
			<td style="text-align:right;">00</td>
			<td id="rate">32,794</td>
			<td style="text-align:right;">00</td>
		</tr>
		<tr>
			<td>2</td>
			<td colspan="2">Toner Cartridge</td>
			<td>1 no</td>
			<td colspan="2" style="text-align:right;">2800</td>
			<td style="text-align:right;">00</td>
			<td style="text-align:right;">2800</td>
			<td style="text-align:right;">00</td>
		</tr>
		<tr style="border-bottom:">
			<td></td>
			<td colspan="2" style="text-align: right; border-top:;"><b>SGST@9%</td>
			<td></td>
			<td colspan="2"></td>
			<td></td>
			<td style="text-align:right;">3,203</td>
			<td style="text-align:right;">46</td>
		</tr>
		<tr style="border-bottom:">
			<td style="border-top: hidden;"></td>
			<td colspan="2" style="text-align: right; border-top:hidden;"><b>CGST@9%</td>
			<td style="border-top: hidden;"></td>
			<td colspan="2" style="border-top: hidden;"></td>
			<td style="border-top: hidden;"></td>
			<td style="text-align:right;">3,203</td>
			<td>46</td>
		</tr>
</table>
<table border="1">
		<tr style="border-top:none;">
			<td colspan="3" id="one"><b>Rupees: Forty two thousand only</b></td>	
			<td colspan="4" id="two"><b>Sales Tax</b></td>
			<td colspan="2" id="three"><b>Inclusive</b></td>
		</tr>
		<tr>
			<td colspan="3"><b>Company Bank Details</b></td>
			<td colspan="4"><b>Service Charges</b></td>
			<td colspan="2"></td>
		</tr>
		<tr>
			<td colspan="3">Name:State Bank Of India</td>
			<td colspan="4"><b>Packing & Forwarding</b></td>
			<td colspan="2"></td>
		</tr>
		<tr>
			<td colspan="3">Account Number:31699658816</td>
			<td colspan="4"><b>Rounded Off Less</b></td>
			<td colspan="2"></td>
		</tr>
		<tr>
			<td colspan="3">Branch IFSC Code:SBIN0014463<br>Branch:Thoothukudi</td>
			<td colspan="4"><b>Total</b></td>
			<td colspan="2"></td>
		</tr>
</table>
<table border="1">
			<tr style="border-top:none;">
			<td style="width:70% !important;" colspan=""><b>Terms & Condition</b><br>Warranty:3 Months or 30,000 copies whichever is earlier<br>Delivery:Within 15 days of your confirmed order<br>Payment:100% in Advance<br>Validity:15 days from the date of Quotation</td>
			<td colspan="2"><center><b>FOR SAKTHI COPIER<br><br><br><br>Authorised Signature</b></center></td>
		</tr>	
</table>
</body>
</html>