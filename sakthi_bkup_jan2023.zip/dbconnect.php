<?php

class db_conn{

	public function connection()
	{
		
	$server="localhost";
	$username="sakthi";
	$password="ganesh73!@#A";
	$dbname="sakthi";
	$conn=mysqli_connect($server,$username,$password,$dbname);
	if($conn->connect_error) {
		die("Connection failed:".$conn->connect_error);
	}
	return $conn;
}		
		
		
		
//		$connect= mysqli_connect($servername,$username,$password,$db);
//		if($connect == false){
//			die("ERROR : Couldn't connrct".mysqli_connect_error());
//		}
//		return $connect;
	}

// $obj =  new db_conn;
// $obj-> connection($db="insert");
?>