<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$fname = $_POST["brname"];
$lname = $_POST["br_remarks"];

$sql="insert into tblbrand(brname,br_remarks)values('$fname','$lname')";

echo$sql;
// $result=mysqli_query($link,$sql);


if(mysqli_query($link, $sql)){
    header("location:stock_entry.php?contact_name='hi'");
    echo "<script>alert('Records added successfully'); </script>";
    } else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }


?>