-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2022 at 04:01 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sakthi`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` longblob NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblbiller`
--

CREATE TABLE `tblbiller` (
  `idno` int(10) NOT NULL,
  `bfname` varchar(100) DEFAULT NULL,
  `blname` varchar(100) DEFAULT NULL,
  `bgender` varchar(100) DEFAULT NULL,
  `bcompany` varchar(100) DEFAULT NULL,
  `bphone` varchar(100) DEFAULT NULL,
  `bemail` varchar(100) DEFAULT NULL,
  `buname` varchar(100) DEFAULT NULL,
  `bpwd` varchar(100) DEFAULT NULL,
  `bstatus` varchar(100) DEFAULT NULL,
  `bgroup` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbiller`
--

INSERT INTO `tblbiller` (`idno`, `bfname`, `blname`, `bgender`, `bcompany`, `bphone`, `bemail`, `buname`, `bpwd`, `bstatus`, `bgroup`) VALUES
(1, '200', '11-02-1990', '-Select-', 'Rs.20000', '', '', '', '', '', ''),
(3, 'h', 'h', '-Select-', 'h', 'h', 'h', 'h', 'h', '-Select-', ''),
(5, 'kali', 'udan', 'Male', 'miga', '23984798', 'thandiya', 'sandlar', '234', '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblbrand`
--

CREATE TABLE `tblbrand` (
  `brid` int(11) NOT NULL,
  `brcreatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `brname` varchar(199) NOT NULL,
  `br_remarks` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbrand`
--

INSERT INTO `tblbrand` (`brid`, `brcreatedate`, `brname`, `br_remarks`) VALUES
(1, '2022-10-04 01:36:15', '', ''),
(2, '2022-10-04 01:36:59', '2', '2'),
(3, '2022-10-04 01:37:11', 'two', 'three'),
(4, '2022-10-06 14:17:46', 'bala', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `catid` int(11) NOT NULL,
  `catname` varchar(100) NOT NULL,
  `catremarks` varchar(100) NOT NULL,
  `cat_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`catid`, `catname`, `catremarks`, `cat_time`) VALUES
(1, '', '', '2022-10-03 10:39:45'),
(2, '', '', '2022-10-03 10:39:45'),
(3, '', '', '2022-10-03 10:39:45'),
(4, '', '', '2022-10-03 10:39:45'),
(5, '', '', '2022-10-03 10:39:45'),
(6, 'om', 'nama', '2022-10-03 10:39:45'),
(7, '', '', '2022-10-03 10:43:22'),
(8, 'thalae', 'lallae loo', '2022-10-03 10:43:56'),
(9, '', '', '2022-10-03 10:46:27'),
(10, 'abc', '123', '2022-10-04 01:21:26'),
(11, '', '', '2022-10-04 01:25:20'),
(12, '', '', '2022-10-04 01:33:42');

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE `tblcustomer` (
  `idno` int(10) NOT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `uname` varchar(100) DEFAULT NULL,
  `pwd` varchar(100) DEFAULT NULL,
  `cstatus` varchar(100) DEFAULT NULL,
  `cgroup` varchar(100) DEFAULT NULL,
  `cus_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`idno`, `fname`, `lname`, `gender`, `company`, `phone`, `email`, `uname`, `pwd`, `cstatus`, `cgroup`, `cus_type`) VALUES
(1, 'mrx', 'mry', '-Select-', 'tuty', '98943879867', '123vema@gmail.com', '12', '121', '-Select-', '12', ''),
(2, '', '', '-Select-', '', '', '', '', '', '-Select-', '', ''),
(3, 'one', 'one', 'Male', 'one', '9790', 'one@gmail.com', 'one', 'one', '2', 'one', ''),
(4, '9', '9', 'Male', '7', '7', '7', '7', '7', '1', '7', ''),
(5, '2', '3', 'Male', '5', '5', '5', '5', '5', '2', '5', ''),
(8, '5', '5', '-Select-', '5', '5', '5', '5', '5', '-Select-', '5', '1'),
(9, 'kannam', 'irandum', 'Male', 'iniyavel', 'kakka', '1278', 'seri', 'peru va', '1', '23', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblnew_invoice_rental`
--

CREATE TABLE `tblnew_invoice_rental` (
  `inv_ren_idno` int(11) NOT NULL,
  `inv_ren_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `inv_ren_date` datetime NOT NULL,
  `inv_ren_cname` varchar(299) NOT NULL,
  `inv_ren_code` varchar(199) NOT NULL,
  `inv_ren_mno` varchar(199) NOT NULL,
  `inv_ren_slno` varchar(289) NOT NULL,
  `inv_ren_mread` varchar(200) NOT NULL,
  `inv_ren_pread` varchar(199) NOT NULL,
  `inv_ren_mdate` datetime NOT NULL,
  `inv_ren_pdate` datetime NOT NULL,
  `inv_ren_sgst` int(11) NOT NULL,
  `inv_ren_cgst` int(11) NOT NULL,
  `inv_ren_pcc` varchar(100) NOT NULL,
  `inv_ren_sno1` varchar(199) NOT NULL,
  `inv_ren_month_rent` varchar(199) NOT NULL,
  `inv_ren_bno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblnew_invoice_rental`
--

INSERT INTO `tblnew_invoice_rental` (`inv_ren_idno`, `inv_ren_created`, `inv_ren_date`, `inv_ren_cname`, `inv_ren_code`, `inv_ren_mno`, `inv_ren_slno`, `inv_ren_mread`, `inv_ren_pread`, `inv_ren_mdate`, `inv_ren_pdate`, `inv_ren_sgst`, `inv_ren_cgst`, `inv_ren_pcc`, `inv_ren_sno1`, `inv_ren_month_rent`, `inv_ren_bno`) VALUES
(1, '2022-10-05 10:18:49', '0000-00-00 00:00:00', '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '', '', '', ''),
(2, '2022-10-05 10:19:26', '2022-10-05 00:00:00', '4', 'code', 'mno', 'sno', 'mread', 'pread', '2022-10-05 00:00:00', '2022-10-05 00:00:00', 0, 0, '7', '7', '7', 'one'),
(3, '2022-10-29 21:57:55', '2022-10-05 00:00:00', '-select-', '123', 'modelgst', 'sno', '90', '20', '2022-10-05 00:00:00', '2022-10-05 00:00:00', 8, 8, '32', '32', '32', '123'),
(4, '2022-10-29 21:57:27', '2020-10-08 00:00:00', '1', '89', '89', '89', '89', '50', '2022-10-15 00:00:00', '2022-10-15 00:00:00', 0, 0, '9', '9', '1', '8new'),
(5, '2022-10-29 21:16:26', '2022-10-28 00:00:00', '2', 'pettai_code', 'pettai_mno', 'pettai_sno', '1000', '900', '2022-10-28 00:00:00', '2022-10-28 00:00:00', 0, 0, '1000', '89', '90', 'bno_pettai');

-- --------------------------------------------------------

--
-- Table structure for table `tblnew_invoice_sales`
--

CREATE TABLE `tblnew_invoice_sales` (
  `inv_sal_idno` int(11) NOT NULL,
  `inv_sal_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `inv_sal_date` datetime NOT NULL,
  `inv_sal_ref` varchar(200) NOT NULL,
  `inv_sal_bno` varchar(100) NOT NULL,
  `inv_sal_cname` varchar(200) NOT NULL,
  `inv_sal_cgst` varchar(100) NOT NULL,
  `inv_sal_sgst` varchar(199) NOT NULL,
  `inv_sal_scharge` varchar(100) NOT NULL,
  `inv_sal_fcharge` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblnew_invoice_sales`
--

INSERT INTO `tblnew_invoice_sales` (`inv_sal_idno`, `inv_sal_created`, `inv_sal_date`, `inv_sal_ref`, `inv_sal_bno`, `inv_sal_cname`, `inv_sal_cgst`, `inv_sal_sgst`, `inv_sal_scharge`, `inv_sal_fcharge`) VALUES
(1, '2022-10-05 15:24:32', '2022-10-05 00:00:00', 'ref', 'bno', 'cus', '8', '8', '800', '800'),
(2, '2022-10-15 15:42:18', '2022-10-15 00:00:00', 'a1ref', 'a1billno', 'a1customer', '8', '8', '8', '8'),
(3, '2022-10-27 23:14:53', '2022-10-28 00:00:00', 't1ref', 't1bno', 't1cutomer', '8', '8', '8', '900'),
(4, '2022-10-27 23:19:12', '2022-10-28 00:00:00', 'un alagal', 'un alagal', 'velyil', '8', '8', '80', '800');

-- --------------------------------------------------------

--
-- Table structure for table `tblnew_invoice_sales_details`
--

CREATE TABLE `tblnew_invoice_sales_details` (
  `inv_sal_idno` int(11) NOT NULL,
  `inv_sal_desc` varchar(200) NOT NULL,
  `inv_sal_qty` varchar(200) NOT NULL,
  `inv_sal_rate` varchar(200) NOT NULL,
  `inv_sal_bno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblnew_invoice_sales_details`
--

INSERT INTO `tblnew_invoice_sales_details` (`inv_sal_idno`, `inv_sal_desc`, `inv_sal_qty`, `inv_sal_rate`, `inv_sal_bno`) VALUES
(1, '3', '3', '3', ''),
(2, '4', '4', '4', ''),
(3, '2', '2', '2', 'bno'),
(4, '2', '2', '2', 'a1billno'),
(5, '2', '2', '2', 'a1billno'),
(6, '1', '1', '1', 't1bno'),
(7, '4', '4', '4', 't1bno'),
(8, '1', '1', '1', 'un alagal'),
(9, '5', '5', '5', 'un alagal');

-- --------------------------------------------------------

--
-- Table structure for table `tblnew_quote_rental`
--

CREATE TABLE `tblnew_quote_rental` (
  `idno` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `qno` varchar(100) NOT NULL,
  `qdate` datetime NOT NULL,
  `qto` varchar(100) NOT NULL,
  `qsubject` varchar(500) NOT NULL,
  `qdesc` varchar(1000) NOT NULL,
  `qrental_amount` varchar(100) NOT NULL,
  `qfree_copies` varchar(100) NOT NULL,
  `qadditional` varchar(100) NOT NULL,
  `qaggrement` varchar(100) NOT NULL,
  `qdeposit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblnew_quote_rental`
--

INSERT INTO `tblnew_quote_rental` (`idno`, `created_date`, `qno`, `qdate`, `qto`, `qsubject`, `qdesc`, `qrental_amount`, `qfree_copies`, `qadditional`, `qaggrement`, `qdeposit`) VALUES
(1, '2022-10-04 11:14:51', '', '0000-00-00 00:00:00', '', '', '', '', '', '', '', 0),
(4, '2022-10-16 02:25:08', '', '2022-10-16 00:00:00', '', '', '', '', '', '', '', 0),
(5, '2022-10-16 02:26:14', 'kuthu', '2022-10-16 00:00:00', 'vel', 'oodas', '9', '9', '9', '9', '9', 9),
(6, '2022-10-27 21:43:00', 'testqno', '2022-10-27 00:00:00', 'testto', 'test', 'test desc', 'test rent', 'rest free', 'test additional', 'test aggre', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_invoice`
--

CREATE TABLE `tblrent_invoice` (
  `idno` int(10) NOT NULL,
  `billno` varchar(100) DEFAULT NULL,
  `rdate` varchar(100) DEFAULT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `rcode` varchar(100) DEFAULT NULL,
  `modelno` varchar(100) DEFAULT NULL,
  `serialno` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrent_invoice`
--

INSERT INTO `tblrent_invoice` (`idno`, `billno`, `rdate`, `cname`, `rcode`, `modelno`, `serialno`) VALUES
(2, '4', '0004-08-04', '-select-', '4', '4', '4');

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_invoice_details`
--

CREATE TABLE `tblrent_invoice_details` (
  `idno` int(10) NOT NULL,
  `billno` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `meter_read` varchar(100) DEFAULT NULL,
  `doread` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_minvoice`
--

CREATE TABLE `tblrent_minvoice` (
  `idno` int(11) NOT NULL,
  `mrdate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `biller` varchar(100) DEFAULT NULL,
  `customer` varchar(100) DEFAULT NULL,
  `cgst` varchar(100) DEFAULT NULL,
  `sgst` varchar(100) DEFAULT NULL,
  `search` varchar(100) DEFAULT NULL,
  `scharge` varchar(100) DEFAULT NULL,
  `packing` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrent_minvoice`
--

INSERT INTO `tblrent_minvoice` (`idno`, `mrdate`, `reference`, `biller`, `customer`, `cgst`, `sgst`, `search`, `scharge`, `packing`) VALUES
(1, '2022-10-05', '', '', '', '', '', '', '', ''),
(2, '2022-10-05', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_minvoice_details`
--

CREATE TABLE `tblrent_minvoice_details` (
  `idno` int(11) NOT NULL,
  `customer` varchar(100) DEFAULT NULL,
  `details` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `rate` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_mquotation`
--

CREATE TABLE `tblrent_mquotation` (
  `idno` int(10) NOT NULL,
  `rmqdate` varchar(100) DEFAULT NULL,
  `rmqto` varchar(100) DEFAULT NULL,
  `rmqsubject` varchar(100) DEFAULT NULL,
  `rmqdetails` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_mquotation_details`
--

CREATE TABLE `tblrent_mquotation_details` (
  `idno` int(11) NOT NULL,
  `rqmto` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `amount` varchar(100) DEFAULT NULL,
  `fcopy` varchar(100) DEFAULT NULL,
  `addition` varchar(100) DEFAULT NULL,
  `agree` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_quotation`
--

CREATE TABLE `tblrent_quotation` (
  `idno` int(10) NOT NULL,
  `rqdate` varchar(100) DEFAULT NULL,
  `rqto` varchar(100) DEFAULT NULL,
  `rqsubject` varchar(100) DEFAULT NULL,
  `rqdetails` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblrent_quotation_details`
--

CREATE TABLE `tblrent_quotation_details` (
  `idno` int(11) NOT NULL,
  `rqdate` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `ramount` varchar(100) DEFAULT NULL,
  `fcopy` varchar(100) DEFAULT NULL,
  `addition` varchar(100) DEFAULT NULL,
  `agree` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblsparesdata`
--

CREATE TABLE `tblsparesdata` (
  `sidno` int(11) NOT NULL,
  `sdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `spare_date` datetime NOT NULL,
  `spare_qno` varchar(100) NOT NULL,
  `spare_to` varchar(200) NOT NULL,
  `spare_subject` varchar(500) NOT NULL,
  `spare_sgst` varchar(100) NOT NULL,
  `spare_cgst` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsparesdata`
--

INSERT INTO `tblsparesdata` (`sidno`, `sdate`, `spare_date`, `spare_qno`, `spare_to`, `spare_subject`, `spare_sgst`, `spare_cgst`) VALUES
(1, '2022-10-05 07:33:14', '2022-10-05 00:00:00', '7', '7', '', '7', '7'),
(2, '2022-10-05 07:34:30', '2022-10-05 00:00:00', '7', '7', '7', '7', '7'),
(3, '2022-10-05 07:36:13', '2022-10-05 00:00:00', 'One', '7', '7', '7', '7'),
(4, '2022-10-05 07:37:49', '2022-10-05 00:00:00', '777', '7', '7', '7', '7'),
(5, '2022-10-05 09:22:00', '2022-10-05 00:00:00', 'Q1', 'test To', 'Test subj', '7', '7'),
(6, '2022-10-05 09:23:55', '2022-10-05 00:00:00', 'Q1', 'test To', 'Test subj', '7', '7'),
(7, '2022-10-05 09:24:08', '2022-10-05 00:00:00', 'Q1', 'test To', 'Test subj', '7', '7'),
(8, '2022-10-05 09:25:59', '2022-10-05 00:00:00', '7', '7', '7', '55', '5'),
(9, '2022-10-05 09:26:20', '2022-10-05 00:00:00', '7', '7', '7', '55', '5'),
(10, '2022-10-05 09:28:03', '2022-10-05 00:00:00', '777', 'bala', 'Try to make quote', '7', '8'),
(11, '2022-10-05 09:29:22', '2022-10-05 00:00:00', '1234', 'To1', 'To Subject', '8', '8'),
(12, '2022-10-15 15:09:12', '2022-10-15 00:00:00', 'a1', 'a1', 'a1 subje', '8', '8'),
(13, '2022-10-27 21:48:56', '2022-10-27 00:00:00', 'testqno', 'test to', 'test subject', '8', '8');

-- --------------------------------------------------------

--
-- Table structure for table `tblspare_adata`
--

CREATE TABLE `tblspare_adata` (
  `sidno` int(11) NOT NULL,
  `sdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `spare_qno` varchar(100) NOT NULL,
  `spare_desc` varchar(500) NOT NULL,
  `spare_rate` varchar(100) NOT NULL,
  `spare_amount` varchar(100) NOT NULL,
  `spare_qty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblspare_adata`
--

INSERT INTO `tblspare_adata` (`sidno`, `sdate`, `spare_qno`, `spare_desc`, `spare_rate`, `spare_amount`, `spare_qty`) VALUES
(1, '2022-10-05 09:24:37', 'Q1', 'Test p1', 'test rate', 'test amt', 'test qty'),
(2, '2022-10-05 09:26:52', '7', '7', '7', '7', '7'),
(3, '2022-10-05 09:26:52', '7', '90', '909', '09', '90'),
(4, '2022-10-05 09:28:05', '777', 'Facewash', '900', '3600', '4'),
(5, '2022-10-05 09:28:05', '777', 'Protein', '1200', '2400', '2'),
(6, '2022-10-05 09:29:22', '1234', 'Mouse', '100', '120', '2'),
(7, '2022-10-05 09:29:22', '1234', 'Pen', '200', '400', '2'),
(8, '2022-10-15 15:09:12', 'a1', 'a1 par', 'a1 rate', 'a1100', 'a1 qty'),
(9, '2022-10-15 15:09:12', 'a1', 'a1 par2', 'a2 rate', 'a1 reqt', 'a1 qty2'),
(10, '2022-10-27 21:48:56', 'testqno', 'test p1', '1200', '36000', '3'),
(11, '2022-10-27 21:48:56', 'testqno', 'test p3', '100', '2000', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tblstock`
--

CREATE TABLE `tblstock` (
  `idno` int(10) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `ptype` varchar(100) DEFAULT NULL,
  `pcode` varchar(100) DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `punit` varchar(100) DEFAULT NULL,
  `mrp` varchar(100) DEFAULT NULL,
  `sprice` varchar(100) DEFAULT NULL,
  `promotion` varchar(100) DEFAULT NULL,
  `hsn` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `alert` varchar(100) DEFAULT NULL,
  `pimage` varchar(200) DEFAULT NULL,
  `invdetail` varchar(100) DEFAULT NULL,
  `supply_name` varchar(100) DEFAULT NULL,
  `partno` varchar(100) DEFAULT NULL,
  `supply_price` varchar(100) DEFAULT NULL,
  `purchase_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstock`
--

INSERT INTO `tblstock` (`idno`, `pname`, `ptype`, `pcode`, `weight`, `brand`, `category`, `punit`, `mrp`, `sprice`, `promotion`, `hsn`, `tax`, `alert`, `pimage`, `invdetail`, `supply_name`, `partno`, `supply_price`, `purchase_date`) VALUES
(5, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(6, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(7, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(9, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(12, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(17, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(21, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(22, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(30, 'om', '', 'na', '', '2', 'om', 'siva', 'ya', 'odi', '', 'utkalantha', '8', 'jothi', 'ADHAR.jpeg', 'kodi ', 'enrianth', 'kodiya', '089', '2022-10-27 00:00:00'),
(31, 'sivay', '', 'om', '', '2', 'om', 'enilae', 'irunth', 'ondrai', '', 'yaan ', '8', 'valarao', 'file_py (1).png', 'om', 'nam', 'siva', '800', '2022-10-27 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbiller`
--
ALTER TABLE `tblbiller`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblbrand`
--
ALTER TABLE `tblbrand`
  ADD PRIMARY KEY (`brid`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblnew_invoice_rental`
--
ALTER TABLE `tblnew_invoice_rental`
  ADD PRIMARY KEY (`inv_ren_idno`);

--
-- Indexes for table `tblnew_invoice_sales`
--
ALTER TABLE `tblnew_invoice_sales`
  ADD PRIMARY KEY (`inv_sal_idno`);

--
-- Indexes for table `tblnew_invoice_sales_details`
--
ALTER TABLE `tblnew_invoice_sales_details`
  ADD PRIMARY KEY (`inv_sal_idno`);

--
-- Indexes for table `tblnew_quote_rental`
--
ALTER TABLE `tblnew_quote_rental`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_invoice`
--
ALTER TABLE `tblrent_invoice`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_invoice_details`
--
ALTER TABLE `tblrent_invoice_details`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_minvoice`
--
ALTER TABLE `tblrent_minvoice`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_minvoice_details`
--
ALTER TABLE `tblrent_minvoice_details`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_mquotation`
--
ALTER TABLE `tblrent_mquotation`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_mquotation_details`
--
ALTER TABLE `tblrent_mquotation_details`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_quotation`
--
ALTER TABLE `tblrent_quotation`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblrent_quotation_details`
--
ALTER TABLE `tblrent_quotation_details`
  ADD PRIMARY KEY (`idno`);

--
-- Indexes for table `tblsparesdata`
--
ALTER TABLE `tblsparesdata`
  ADD PRIMARY KEY (`sidno`);

--
-- Indexes for table `tblspare_adata`
--
ALTER TABLE `tblspare_adata`
  ADD PRIMARY KEY (`sidno`);

--
-- Indexes for table `tblstock`
--
ALTER TABLE `tblstock`
  ADD PRIMARY KEY (`idno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblbiller`
--
ALTER TABLE `tblbiller`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblbrand`
--
ALTER TABLE `tblbrand`
  MODIFY `brid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblnew_invoice_rental`
--
ALTER TABLE `tblnew_invoice_rental`
  MODIFY `inv_ren_idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblnew_invoice_sales`
--
ALTER TABLE `tblnew_invoice_sales`
  MODIFY `inv_sal_idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblnew_invoice_sales_details`
--
ALTER TABLE `tblnew_invoice_sales_details`
  MODIFY `inv_sal_idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblnew_quote_rental`
--
ALTER TABLE `tblnew_quote_rental`
  MODIFY `idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblrent_invoice`
--
ALTER TABLE `tblrent_invoice`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblrent_invoice_details`
--
ALTER TABLE `tblrent_invoice_details`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrent_minvoice`
--
ALTER TABLE `tblrent_minvoice`
  MODIFY `idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblrent_minvoice_details`
--
ALTER TABLE `tblrent_minvoice_details`
  MODIFY `idno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrent_mquotation`
--
ALTER TABLE `tblrent_mquotation`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrent_mquotation_details`
--
ALTER TABLE `tblrent_mquotation_details`
  MODIFY `idno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrent_quotation`
--
ALTER TABLE `tblrent_quotation`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrent_quotation_details`
--
ALTER TABLE `tblrent_quotation_details`
  MODIFY `idno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsparesdata`
--
ALTER TABLE `tblsparesdata`
  MODIFY `sidno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblspare_adata`
--
ALTER TABLE `tblspare_adata`
  MODIFY `sidno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblstock`
--
ALTER TABLE `tblstock`
  MODIFY `idno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
