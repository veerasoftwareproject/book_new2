<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];
$pay_emi = $_REQUEST['pay_emi'];
$pay_type = $_REQUEST['pay_type'];
$pay_billno=$_REQUEST['pay_billno'];


#$sql="Delete from tblpayment where id='$rid'";
#$res=mysqli_query($link,$sql) or die(mysqli_error());
#echo$sql;
$tot_amt_final=0;

if($pay_type=='AMC'){
    $a1="select * from tblamc where amc_no='$pay_billno'";
    $qr1=mysqli_query($link,$a1);

    while($dt1=mysqli_fetch_array($qr1))
    {
        $amt = $ab1['amc_paid'];
        $less=$amt - $pay_emi; 
    }					  
    $sql21="update tblamc set amc_paid='$less' where amc_no='$pay_billno'";
	echo$sql21;
    $res=mysqli_query($link,$sql21) or die(mysqli_error());
}

// ******************************************************************************************
else if($pay_type=='Sales'){
    $a1=mysqli_query($link,"select * from tblnew_invoice_sales where inv_sal_bno='$pay_billno'");
    while($ab1=mysqli_fetch_array($a1))
    {
        $amt = $ab1['inv_sal_paid_amt'];
        $less=$amt- $pay_emi;
    } 
    $sql22="update tblnew_invoice_sales set inv_sal_paid_amt = '$less' where inv_sal_bno='$pay_billno'";
		echo$sql22;
    $res=mysqli_query($link,$sql22) or die(mysqli_error());
}
// ******************************************************************************************
else if($pay_type=='Rental'){
    $a1=mysqli_query($link,"select * from tblnew_invoice_rental where inv_ren_bno='$pay_billno'");
    while($ab1=mysqli_fetch_array($a1))
    {
        $amt = $ab1['inv_ren_paid'];
        $less=$amt- $pay_emi;
    } 
    $sql23="update tblnew_invoice_rental set inv_ren_paid='$less' where inv_ren_bno='$pay_billno'";
		echo$sql23;
    $res=mysqli_query($link,$sql23) or die(mysqli_error());
}
else if($pay_type=='Purchase'){
    $n1=mysqli_query($link,"select * from tblnew_purchase where pbillno='$pay_billno'");
	//echo$n1;
    while($na1=mysqli_fetch_array($n1))
    {
        $amt = $na1['p_paid_amt'];
        $less=$amt - $pay_emi; 
    }		
	echo"Less:".$less;
    $nab1="update tblnew_purchase set p_paid_amt='$less' where pbillno='$pay_billno'";
	echo$nab1;
    $res=mysqli_query($link,$nab1) or die(mysqli_error());
}


$sql2="Delete from tblpayment where id='$rid'";
echo$sql2;
$res=mysqli_query($link,$sql2) or die(mysqli_error());
#header("location:sales_payment.php");

?>