<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();




$fname = $_GET["bfname"];
$lname = $_GET["blname"];
$gender = $_GET["bgender"];
// $company = $_GET["bcompany"];
$phone = $_GET["bphone"];
$email = $_GET["bemail"];
$uname = $_GET["buname"];
$pwd = $_GET["bpwd"];
$status = $_GET["bstatus"];
$group = $_GET["bgroup"];


$sql="insert into tblservice_engg(sfname,slname,sgender,sphone,semail,suname,spwd,sstatus,sgroup)values('$fname','$lname','$gender','$phone','$email','$uname','$pwd','$status','$group')";

// echo$sql;

$result=mysqli_query($link,$sql);




?>