<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];

$sql="Delete from tblnew_purchase where pbillno='$rid'";
$res=mysqli_query($link,$sql) or die(mysqli_error());
echo$sql;



$sql2="Delete from tblnew_purchase_details where pbillno='$rid'";
$res2=mysqli_query($link,$sql2) or die(mysqli_error());
echo$sql2;


header("location:purchase_invoice_display.php");


?>