<?php


include 'dbconnect.php';
$object = new db_conn();
$link=$object-> connection();
$bno= $_GET["bno"];
$a = $_GET["ar1"];
$b = $_GET["ar2"]; //qty
$c = $_GET["ar3"]; //rate
// echo$vt2;
for ($i=0; $i<count($a); $i++)
{
      $query="insert into tblnew_invoice_sales_details(inv_sal_bno,inv_sal_desc,inv_sal_qty,inv_sal_rate)
	  values('$bno','$a[$i]','$b[$i]','$c[$i]')";
      echo$query;
    if(mysqli_query($link, $query)){
      // header("location:stock_entry.php?contact_name='hi'");
      // echo "<script>alert('Records added successfully'); </script>";
      echo$query;
      }
    //   $qrexe = $conn->query($query);

}
?>








<!-- ?> -->