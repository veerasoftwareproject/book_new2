<?php

include 'crud.php';		//class file

$obj = new crud();		//object create

				
$id=$_GET["id"]; //value get
// $id=$_GET["id"];

// $obj->hello_insert("crud","qparticular","qamount",$x,$amt); //function call

$obj->deleteid("tblsparesdata","spare_qno",$id);

header("location:rental_mquotation_display.php");

// mysqli_close($link);




?>