<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];

$sql="Delete from tblnew_invoice_sales where inv_sal_bno='$rid'";
$res=mysqli_query($link,$sql) or die(mysqli_error());
echo$sql;
header("location:sales_invoice_display.php");


?>