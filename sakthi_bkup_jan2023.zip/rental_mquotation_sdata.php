<?php
include 'dbconnect.php';
$object = new db_conn();
$link=$object-> connection();

echo"db connected";

$rqdate=$_GET["rqdate"];		//value get
$rqto = $_GET["rqto"];
$rqsub = $_GET["rqsub"];
$rqno = $_GET["qno"];
$sgst=$_GET['sgst'];
$cgst=$_GET['cgst'];

// echo$rqdate." ".$rqto." ".$rqsub." ".$sgst." ".$cgst;

 $sql="insert into tblsparesdata(spare_date,spare_qno,spare_to,spare_subject,spare_sgst,spare_cgst)values('$rqdate','$rqno','$rqto','$rqsub','$sgst','$cgst')";


if(mysqli_query($link, $sql)){
    // header("location:stock_entry.php?contact_name='hi'");
    // echo "<script>alert('Records added successfully'); </script>";
    echo$sql;
    } else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
    
?>
