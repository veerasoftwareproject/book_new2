<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SAKTHI COPIER | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<?php
include 'nav.php';
include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Invoice</a></li>
              <li class="breadcrumb-item active">Edit/Delete</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <!-- /.card -->
            <!-- Horizontal Form -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">STOCK ENTRY</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" method="POST" action="stock_entrysdata.php" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group row">
                    <label for="pname" class="col-sm-2 col-form-label">Product Name</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="pname" placeholder="">
                    </div>
                  </div>
                  <!-- <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Product Type</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="ptype" placeholder="">
                    </div>
                  </div> -->

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Product Code</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="pcode" placeholder="">
                    </div>
                  </div>

                   <!-- <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Weight </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="weight" placeholder="">
                    </div>
                  </div> -->


                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Brand(db)</label>
                    <div class="col-sm-10">
                      <select class="form-control" name="brand">
                          <option value="">-select-</option>
<?php
$qr=mysqli_query($link,"select distinct(brname) from tblbrand where brname!=''");
$ct=0;

while($dt=mysqli_fetch_array($qr)){
// $ct=$ct+1;
// echo$qr;
?>

                          <option value='<?php echo$dt['brname']; ?>'><?php echo$dt['brname']; } ?></option>
                          <!-- <option value="2">option 2</option> -->
                          <!-- <option value="3">option 3</option> -->
                          <!-- <option value="4">option 4</option> -->
                          <!-- <option value="5">option 5</option> -->

                        </select>
                        <a href="stock_entry_brand.php">+ Addnew</a>
                      </div>
                  </div>

                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Category()</label>
                    <div class="col-sm-10">
                    <select class="form-control" name="category">
                          <option value="">-select-</option>
<?php
$qr=mysqli_query($link,"select distinct(catname) from tblcategory where catname!=''");
$ct=0;

while($dt=mysqli_fetch_array($qr)){
// $ct=$ct+1;
// echo$qr;
?>

                          <option value='<?php echo$dt['catname']; ?>'><?php echo$dt['catname']; } ?></option>
                          <!-- <option value="2">option 2</option> -->
                          <!-- <option value="3">option 3</option> -->
                          <!-- <option value="4">option 4</option> -->
                          <!-- <option value="5">option 5</option> -->

                        </select>                        <a href="stock_entry_category.php">+ Addnew</a>
                      </div>
                  </div>

                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Product Unit </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="punit" placeholder="">
                    </div>
                  </div>

                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label"> MRP </label>
                    <div class=" input-group-append col-sm-10">
                      <span class="input-group-text">RS.</span>
                      <input type="text" class="form-control" name="mrp" placeholder="">
                      <div class="input-group-append">
                        <span class="input-group-text">.00</span>
                      </div>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label"> Sell Price </label>
                    <div class=" input-group-append col-sm-10">
                      <span class="input-group-text">RS.</span>
                      <input type="text" class="form-control" name="sprice" placeholder="">
                      <div class="input-group-append">
                        <span class="input-group-text">.00</span>
                      </div>
                    </div>
                  </div>

                 

                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">HSN Code</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="hsn" placeholder="">
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Tax Method(%)</label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="tax" placeholder="">
                    <!-- <select class="form-control" name="tax">
                          <option value="">-select-</option>
                          <option value="1">option 1</option>
                          <option value="2">option 2</option>
                          <option value="3">option 3</option> 
                          <option value="4">option 4</option>
                          <option value="5">option 5</option>
                        </select> -->
                      </div>
                  </div>

                   <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Alert Qt []</label>
                    <div class="input-group-append col-sm-10">
                      <input type="text" class="form-control" name="palert">
                        <div class="input-group-append">
                          <span class="input-group-text"><i class="fas fa-check"></i></span>
                        </div>
                    </div>
                  </div> 




                   <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Product Image</label>
                    <div class="col-sm-10">
                      <input type="file" class="form-control" name="imagetmp">
                        <!-- <div class="input-group-append">
                          <span class="input-group-text"><i class="fas fa-check"></i></span>
                        </div> -->
                    </div>
                  </div>  

                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Product Invoice Detail</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="invdetail" placeholder="">
                    </div>
                  </div>

                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Supplier Name</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="supname" placeholder="">
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Part No</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="partno" placeholder="">
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label"> Supplier Price </label>
                    <div class=" input-group-append col-sm-10">
                      <span class="input-group-text">RS.</span>
                      <input type="text" class="form-control" name="sup_price" placeholder="">
                      <div class="input-group-append">
                        <span class="input-group-text">.00</span>
                      </div>
                    </div>
                  </div> 
                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label"> Purchase Date </label>
                    <div class=" input-group-append col-sm-10">
                      <!-- <span class="input-group-text">RS.</span> -->
                      <input type="date" class="form-control" name="pur_date" value="<?php echo date('Y-m-d'); ?>" placeholder="">
                      <div class="input-group-append">
                        <!-- <span class="input-group-text"></span> -->
                      </div>
                    </div>
                  </div>                   
                  <!-- </div> -->
                 
                <!-- /.card-body -->
                <!-- <div class="card-footer"> -->
                 
                  <input type="submit" value="ADD PRODUCT" id="btnadd" class="btn btn-info float-right">
                <!-- </div> -->
                <!-- /.card-footer -->
              </form>
            </div>

            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
  
    

 </body>
 </html>
 <!-- <script type="text/javascript">
   $(document).ready(function() {
     $("#btnadd").click(function(){
      
      // alert("working");

       var pname = $("#pname").val();
       var ptype = $("#ptype").val();
       var pcode = $("#pcode").val();
       var weight = $("#weight").val();
       var brand = $("#brand").val();
       var category = $("#category").val();
       var punit = $("#punit").val();
       var mrp = $("#mrp").val();
       var sprice = $("#sprice").val();
       var promotion = $("#promotion").val();
       var hsn = $("#hsn").val();
       var tax = $("#tax").val();
       var palert = $("#alert").val();
       var pimage = $("#imagetmp").val();
       alert("image:"+pimage);
       var invdetail = $("#invdet").val();
       var supname = $("#supname").val();
       var partno = $("#partno").val();
       var sup_price = $("#suprice").val();
       var pur_date = $("#purchase_date").val();
        // alert(pur_date);


       $.ajax({

        url : "stock_entrysdata.php",
        method : "POST",
        data : {pname:pname, ptype:ptype, pcode:pcode, weight:weight, brand:brand, category:category, punit:punit, mrp:mrp, sprice:sprice, promotion:promotion, hsn:hsn, tax:tax, palert:palert, pimage:pimage, invdetail:invdetail, supname:supname, partno:partno, sup_price:sup_price, pur_date:pur_date},
        
        success : function(response){
          alert("stock entry collected");

        }
      });



        // $("#pname").val("");
        // $("#ptype").val("");
        // $("#pcode").val("");
        // $("#weight").val("");
        // $("#brand").val("");
        // $("#category").val("");
        // $("#punit").val("");
        // $("#mrp").val("");
        // $("#sprice").val("");
        // $("#promotion").val("");
        // $("#hsn").val("");
        // $("#tax").val("");
        // $("#alert").val("");
        // $("#image").val("");
        // $("#invdet").val("");
        // $("#supname").val("");
        // $("#partno").val("");
        // $("#suprice").val("");
        // $("#pname").focus();


       

     });
   });
 </script> -->