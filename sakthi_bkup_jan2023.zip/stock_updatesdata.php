<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();


// $status = $statusMsg = ''; 
// if(isset($_GET["submit"])){ 
//     $status = 'error'; 
//     if(!empty($_FILES["image"]["name"])) { 
//         // Get file info 
//         $fileName = basename($_FILES["image"]["name"]); 
//         $fileType = pathinfo($fileName, PATHINFO_EXTENSION); 
         
//         // Allow certain file formats 
//         $allowTypes = array('jpg','png','jpeg','gif'); 
//         if(in_array($fileType, $allowTypes)){ 
//             $image = $_FILES['image']['tmp_name']; 
//             $imgContent = addslashes(file_get_contents($image)); 
         
//             // Insert image content into database 
//             $insert = $db->query("INSERT into images (image, created) VALUES ('$imgContent', NOW())"); 
             
//             if($insert){ 
//                 $status = 'success'; 
//                 $statusMsg = "File uploaded successfully."; 
//             }else{ 
//                 $statusMsg = "File upload failed, please try again."; 
//             }  
//         }else{ 
//             $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.'; 
//         } 
//     }else{ 
//         $statusMsg = 'Please select an image file to upload.'; 
//     } 
// } 
 
// // Display status message 
// echo $statusMsg; 
$pid=$_GET['idno'];

 $pname = $_GET["pname"];
 $ptype = $_GET["ptype"];
 $pcode = $_GET["pcode"];
 $weight = $_GET["weight"];
 $brand = $_GET["brand"];
 $category = $_GET["category"];
 $punit = $_GET["punit"];
 $mrp = $_GET["mrp"];
 $sprice = $_GET["sprice"];
 $promotion = $_GET["promotion"];
 $hsn = $_GET["hsn"];
 $tax = $_GET["tax"];
 $palert = $_GET["palert"];
 $pimg = $_GET["pimage"];
 $invdet = $_GET["invdetail"];
 $supname = $_GET["supname"];
 $partno = $_GET["partno"];
 $sup_price = $_GET["sup_price"];
 $pur_date = $_GET["pur_date"];
 // echo"working"."<br>".$sup_price; 


 // $sql="insert into tblstock(pname,ptype,pcode,weight,brand,category,punit,mrp,sprice,promotion,hsn,tax,alert,pimage,invdetail,supply_name,partno,supply_price,purchase_date)values('$pname','$ptype','$pcode','$weight','$brand','$category','$punit','$mrp','$sprice','$promotion','$hsn','$tax','$palert','$pimg','$invdet','$supname','$partno','$sup_price','$pur_date')";
 
$sql="update tblstock set pname='$pname', ptype='$ptype', pcode='$pcode', weight='$weight', brand='$brand', category='$category', punit='$punit', mrp='$mrp',sprice='$sprice', promotion='$promotion',hsn='$hsn',tax='$tax',alert='$palert',pimage='$pimg', invdetail='$invdet', supply_name='$supname', partno='$partno', supply_price='$sup_price', purchase_date='$pur_date' where idno='$pid' ";

 echo$sql;

 $result=mysqli_query($link,$sql);



// echo$sql;
// mysql_close($link);
?>