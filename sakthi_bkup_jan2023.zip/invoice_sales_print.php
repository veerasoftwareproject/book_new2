<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<style type="text/css">
	table{
		width: 100%;
		border-collapse: collapse;
		line-height: 25px;
		/*border: 1px solid black;*/
	}
	#customer_col{
		width: 80%;
	}
	#ps{
		width:2% !important;
	}
	#qty{
		width: 5% !important;
	}
	#slno{
		width: 5% !important;
		text-align: center;
	}
	#rate{
		width: 15% !important;
		text-align: right;
	}
	#one{
		width: 60% !important;
	}
	#two{
		width: 25% !important;
	}
	#three{
		width: 15% !important;
	}
</style>
<body>

<?php
include "dbconnect.php";

$bno = $_GET['id'];
$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblnew_invoice_sales where inv_sal_bno='$bno'");
$ct=0;

while($dt=mysqli_fetch_array($qr)){
$ct=$ct+1;
?>
	<br><br>
<center> <b> "V FOR U" </b></center>
<table>
<tr>	
<td style="text-align:right;" > <b> INVOICE </b></td> <td style="text-align:right;"> <b> Original </b></td> 
</tr>	
</table>
<table border="1">
	<tr>
		<td><span>SAKTHI COPIER</span><br>17/5Perumal Car Street, Tirunelveli-627001.<br>36A,Subbiahpuram,2nd Street,Tuticorin-3.<br>Cell:94431-72023/99940 28206.</td>
		<td>Our Sales Tax Number<br>GST IN :33BOPS2206C1ZL<br>Pan No;BOBPS2206C</td>
	</tr>
</table>
<table border="1">
		<tr style="border-top: none;">
			<td id="customer_col" rowspan="4"><span>Customer</span><br>MS.<?php echo$dt['inv_sal_cname']; ?>,<?php 
	$n1= $dt['inv_sal_cname'];
	$cqr=mysqli_query($link,"select * from tblcustomer WHERE company='$n1'");
	while($cdt=mysqli_fetch_array($cqr)){
	echo$cdt['caddress']; ?>,<br>
<?php echo$cdt['phone']; } ?>
				
				
				<b></td>
			<td colspan="">Inv.No.</td>
			<td colspan=""><?php echo$dt['inv_sal_bno']; ?></td>
			<!-- <td></td>	 -->
		</tr>
		<tr>
			<td colspan="">Date</td>
			<td colspan=""><?php echo$dt['inv_sal_date']; ?></td>
		</tr>
		<tr>
			<td colspan="">Your Ref.No.</td>
			<td colspan=""><?php echo$dt['inv_sal_ref'];  ?></td>
		</tr>
		<tr>
			<!-- <td colspan="">Date</td>
			<td colspan="">05.02.2022</td> -->
		</tr>
</table>



<table border="1">
		<tr style="border-top:none;">
			<th rowspan="" style="width:2% !important;" id="slno">SI.No.</th>	
			<th colspan="2" rowspan="">Description</th>
			<th rowspan="" id="qty">Qty.</th>
			<th colspan="3"  id="rate" rowspan="">Unit Price</th>
			<th colspan="2" rowspan="">Amount</th>
		</tr>

		<tr>
			<td  id="slno" style="border-top: hidden;"></td>
			<td colspan="2" style="border-top: hidden;"></td>
			<td style="border-top: hidden;" id="qty"></td>
			<td colspan="2">RS.</td>
			<td id="ps">Ps.</td>
			<td>RS.</td>
			<td id="ps">Ps.</td>
		</tr>
<?php
$qr2=mysqli_query($link,"select * from tblnew_invoice_sales_details where inv_sal_bno='$bno'");
$ct2=0;
$tot_amt_final=0;
while($dt2=mysqli_fetch_array($qr2)){
$ct2=$ct2+1;
?>

		<tr>
			<td><?php echo$ct2; ?></td>
			<td colspan="2"><?php echo$dt2['inv_sal_desc']; ?></td>
			<td><?php echo$dt2['inv_sal_qty']; ?> no</td>
			<td colspan="2" style="text-align:right;"><?php echo$dt2['inv_sal_rate']; ?></td>
			<td style="text-align:right;">00</td>
			<td id="rate"><?php
			$tot_amt = $dt2['inv_sal_qty']* $dt2['inv_sal_rate']; echo$tot_amt;
			$tot_amt_final = $tot_amt_final +$tot_amt;   ?>
			</td>
			<td style="text-align:right;">00</td>
		</tr>
		<?php  }  ?>
		<tr style="border-bottom:">
			<td></td>
			<td colspan="2" style="text-align: right; border-top:;"><b>SGST@<?php echo$dt['inv_sal_sgst']; ?>%</td>
			<td></td>
			<td colspan="2"></td>
			<td></td>
			<td style="text-align:right;"><?php $gst_amt = $dt['inv_sal_sgst']* 0.01 * $tot_amt; echo$gst_amt;?></td>
			<td style="text-align:right;">00</td>
		</tr>
		<tr style="border-bottom:">
			<td style="border-top: hidden;"></td>
			<td colspan="2" style="text-align: right; border-top:hidden;"><b>CGST@<?php echo$dt['inv_sal_cgst'];  ?>%</td>
			<td style="border-top: hidden;"></td>
			<td colspan="2" style="border-top: hidden;"></td>
			<td style="border-top: hidden;"></td>
			<td style="text-align:right;"><?php $gst_amt2 = $dt['inv_sal_cgst']* 0.01 * $tot_amt; echo$gst_amt2;
			$bill_amt = $gst_amt+$gst_amt2+$tot_amt_final +$dt['inv_sal_fcharge'] + $dt['inv_sal_scharge']; ?></td>
			<td style="text-align:right;" >00</td>
		</tr>
</table>
	
<?php 
include"no2text.php";
$get_amount= AmountInWords($bill_amt);
?>
<table border="1" style="">
		<tr style="border-top:none;">

			<td colspan="3" id="one"><b>Rupees: <?php echo$get_amount; ?> only</b></td>	
			<td colspan="4" id="two"><b>Sales Tax</b></td>
			<td colspan="2" id="three"><b>Inclusive</b></td>
		</tr>
		<tr>
			<td colspan="3"><b>Company Bank Details</b></td>
			<td colspan="4"><b>Service Charges</b></td>
			<td colspan="2" style="text-align:right;"><?php echo$dt['inv_sal_scharge'];  ?>.00</td>
		</tr>
		<tr>
			<td colspan="3">Name:State Bank Of India</td>
			<td colspan="4"><b>Packing & Forwarding</b></td>
			<td colspan="2" style="text-align:right;"><?php echo$dt['inv_sal_fcharge']; } ?>.00</td>
		</tr>
		<tr>
			<td colspan="3">Account Number:31699658816</td>
			<td colspan="4"><b>Rounded Off Less:</b></td>
			<td colspan="2" style="text-align:right;">00</td>
		</tr>
		<tr>
			<td colspan="3">Branch IFSC Code:SBIN0014463<br>Branch:Thoothukudi</td>
			<td colspan="4"><b>Total</b></td>
			<td colspan="2" style="text-align:right;"><?php echo$bill_amt.".00"; ?></td>
		</tr>
</table>
<table border="1">
			<tr style="border-top:none;">
			<td style="width:70% !important;" colspan=""><b>Terms & Condition</b><br>Warranty:3 Months or 30,000 copies whichever is earlier<br>Delivery:Within 15 days of your confirmed order<br>Payment:100% in Advance<br>Validity:15 days from the date of Quotation</td>
			<td colspan="2"><center><b>FOR SAKTHI COPIER<br><br><br><br>Authorised Signature</b></center></td>
		</tr>	
</table>
</body>
</html>