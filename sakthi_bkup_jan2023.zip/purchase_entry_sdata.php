<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$date=$_GET["mrdate"];
$ref=$_GET["ref"];
$bno=$_GET["bno"];
$customer=$_GET["customer"];
$cgst=$_GET["cgst"];
$sgst=$_GET["sgst"];
// $search=$_GET["search"];
$scharge=$_GET["scharge"];
$pack=$_GET["pack"];


$sql="insert into tblnew_invoice_sales(inv_sal_date,inv_sal_ref,inv_sal_bno,inv_sal_cname,inv_sal_cgst,inv_sal_sgst,inv_sal_scharge,inv_sal_fcharge)
values('$date','$ref','$bno','$customer','$cgst','$sgst','$scharge','$pack')";


$result=mysqli_query($link,$sql);

echo$sql;
?>